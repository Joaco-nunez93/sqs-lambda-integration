export const handler = (event: any) => {

console.log(event)

const result = {
    statusCode: 200,
    body: "Success"
}

return result

}