export const handler = (event) => {

console.log(event)

const result = {
    statusCode: 200,
    body: "Success"
}

return result

}